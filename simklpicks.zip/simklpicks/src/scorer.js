export function buildUserProfile({ history }) {
  const genres = new Map();
  for (const item of history || []) {
    const gs = item?.show?.genres || item?.movie?.genres || [];
    for (const g of gs) genres.set(g, (genres.get(g) || 0) + 1);
  }
  const total = Array.from(genres.values()).reduce((a,b)=>a+b,0) || 1;
  const affinity = {};
  for (const [g, c] of genres.entries()) affinity[g] = c / total;
  return { affinity };
}
function genreAffinityScore(affinity, itemGenres) {
  if (!itemGenres || !itemGenres.length) return 0;
  let s = 0;
  for (const g of itemGenres) s += (affinity[g] || 0);
  return Math.min(1, s / itemGenres.length);
}
export function scoreItem({ item, inWatchlist, profile }) {
  const genres = item?.genres || [];
  const rating = (item?.ratings?.rating || 0) / 10;
  const genreScore = genreAffinityScore(profile.affinity || {}, genres);
  const watchlistBoost = inWatchlist ? 0.3 : 0;
  return rating * 0.6 + genreScore * 0.4 + watchlistBoost;
}
export function normalizeTopN(items, topN = 50) {
  return items.sort((a,b)=> b.score - a.score).slice(0, topN);
}
