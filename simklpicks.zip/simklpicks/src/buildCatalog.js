import { buildUserProfile, scoreItem, normalizeTopN } from './scorer.js';
function toMetaPreview(simklItem, type) {
  const base = simklItem[type] || simklItem;
  const ids = base?.ids || {};
  const id = ids.imdb || (ids.tmdb ? `tmdb:${ids.tmdb}` : (ids.tvdb ? `tvdb:${ids.tvdb}` : (base?.slug || base?.title)));
  return {
    id,
    name: base?.title || base?.name || base?.show_title || base?.movie_title || 'Unknown',
    poster: base?.poster || base?.image || undefined,
    posterShape: 'poster',
    year: base?.year,
    genres: base?.genres || [],
    ratings: base?.ratings || {}
  };
}
function uniqueById(arr) {
  const seen = new Set(); const out = [];
  for (const it of arr) { if (!it || !it.id) continue; if (seen.has(it.id)) continue; seen.add(it.id); out.push(it); }
  return out;
}
export async function buildCatalog({ client, type, listId }) {
  const [histRaw, wlRaw, ratingsRaw] = await Promise.all([
    type === 'movie' ? client.historyMovies() : client.historyShows(),
    type === 'movie' ? client.watchlistMovies() : client.watchlistShows(),
    type === 'movie' ? client.ratingsMovies() : client.ratingsShows()
  ]);
  const historyItems = (histRaw || []).map(x => toMetaPreview(x, type));
  const watchlistItems = (wlRaw || []).map(x => toMetaPreview(x, type));
  const watchIds = new Set(watchlistItems.map(i => i.id));
  const ratedMap = new Map((ratingsRaw || []).map(x => {
    const m = toMetaPreview(x, type);
    const r = x?.rating?.rating || x?.rating || 0;
    return [m.id, r];
  }));
  const profile = buildUserProfile({ history: histRaw });
  let pool = [];
  if (listId === 'simklpicks.finish-the-series' && type === 'series') {
    pool = uniqueById([...historyItems, ...watchlistItems]);
  } else {
    pool = uniqueById([...watchlistItems, ...historyItems]);
  }
  if (listId.includes('high-rated-not-watched')) {
    const watched = new Set(historyItems.map(i => i.id));
    pool = pool.filter(i => !watched.has(i.id));
  }
  const scored = pool.map(item => ({
    ...item,
    score: scoreItem({ item, inWatchlist: watchIds.has(item.id), profile })
  }));
  return normalizeTopN(scored, 50);
}
