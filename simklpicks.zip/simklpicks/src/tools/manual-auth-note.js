console.log('Simkl OAuth: see README. Provide SIMKL_ACCESS_TOKEN in .env.');
