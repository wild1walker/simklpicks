import fetch from 'node-fetch';
export class SimklClient {
  constructor({ apiKey, accessToken, cacheMinutes = 30 }) {
    this.apiKey = apiKey;
    this.accessToken = accessToken;
    this.base = 'https://api.simkl.com';
    this.cacheMs = cacheMinutes * 60 * 1000;
    this.cache = new Map();
  }
  headers() {
    return {
      'Content-Type': 'application/json',
      'simkl-api-key': this.apiKey,
      ...(this.accessToken ? { 'Authorization': `Bearer ${this.accessToken}` } : {})
    };
  }
  async _get(path) {
    const url = `${this.base}${path}`;
    const cached = this.cache.get(url);
    const now = Date.now();
    if (cached && (now - cached.ts) < this.cacheMs) return cached.data;
    const res = await fetch(url, { headers: this.headers() });
    if (!res.ok) throw new Error(`SIMKL GET ${path} failed: ${res.status} ${await res.text()}`);
    const data = await res.json();
    this.cache.set(url, { ts: now, data });
    return data;
  }
  lastActivities() { return this._get('/sync/last_activities'); }
  historyMovies()   { return this._get('/sync/history/movies'); }
  historyShows()    { return this._get('/sync/history/shows'); }
  watchlistMovies() { return this._get('/sync/watchlist/movies'); }
  watchlistShows()  { return this._get('/sync/watchlist/shows'); }
  ratingsMovies()   { return this._get('/sync/ratings/movies'); }
  ratingsShows()    { return this._get('/sync/ratings/shows'); }
}
