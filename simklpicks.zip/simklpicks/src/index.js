import 'dotenv/config';
import { addonBuilder } from 'stremio-addon-sdk';
import { SimklClient } from './simklClient.js';
import { buildCatalog } from './buildCatalog.js';
const manifest = {
  id: 'org.abraham.simklpicks',
  version: '1.0.0',
  name: 'SimklPicks',
  description: 'Recommended lists based on your Simkl watchlists & history',
  resources: ['catalog'],
  types: (process.env.TYPES || 'movie,series').split(',').map(s => s.trim()),
  idPrefixes: ['tt', 'tmdb', 'tvdb'],
  catalogs: [
    { type: 'movie', id: 'simklpicks.top-genres', name: 'SimklPicks • Top Genres' },
    { type: 'movie', id: 'simklpicks.high-rated-not-watched', name: 'SimklPicks • High Rated Unwatched' },
    { type: 'series', id: 'simklpicks.top-genres', name: 'SimklPicks • Top Genres' },
    { type: 'series', id: 'simklpicks.finish-the-series', name: 'SimklPicks • Finish the Series' },
    { type: 'series', id: 'simklpicks.high-rated-not-watched', name: 'SimklPicks • High Rated Unwatched' }
  ]
};
const builder = addonBuilder(manifest);
const client = new SimklClient({
  apiKey: process.env.SIMKL_API_KEY,
  accessToken: process.env.SIMKL_ACCESS_TOKEN,
  cacheMinutes: parseInt(process.env.CACHE_MINUTES || '30', 10)
});
builder.defineCatalogHandler(async ({ type, id }) => {
  try {
    const metas = await buildCatalog({ client, type, listId: id });
    return { metas };
  } catch (e) {
    console.error('Catalog error', e);
    return { metas: [] };
  }
});
const { serveHTTP } = await import('stremio-addon-sdk');
serveHTTP(builder.getInterface(), { port: Number(process.env.PORT) || 7769 });
console.log(`[SimklPicks] manifest: http://localhost:${process.env.PORT || 7769}/manifest.json`);
