# SimklPicks — Stremio addon
Recommended catalogs built from your Simkl watchlists & history.

## Quick start
1) Node 18+
2) Create Simkl API key + access token
3) Copy .env.example to .env and fill
4) npm i && npm start
5) Install manifest URL in Stremio

See README in the zip for more.
