console.log('Simkl OAuth: Provide SIMKL_ACCESS_TOKEN in .env');
