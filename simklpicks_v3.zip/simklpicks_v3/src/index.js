import 'dotenv/config';
import { addonBuilder } from 'stremio-addon-sdk';
import { SimklClient } from './simklClient.js';
import { buildCatalog } from './buildCatalog.js';
import http from 'http';

const manifest = {
  id: 'org.abraham.simklpicks',
  version: '1.2.0',
  name: 'SimklPicks',
  description: 'Recommendations from your Simkl watchlists & history',
  resources: ['catalog'],
  types: (process.env.TYPES || 'movie,series').split(',').map(s => s.trim()),
  idPrefixes: ['tt', 'tmdb', 'tvdb'],
  catalogs: [
    { type: 'series', id: 'simklpicks.recommended-series', name: 'SimklPicks • Recommended Series' },
    { type: 'movie',  id: 'simklpicks.recommended-movies', name: 'SimklPicks • Recommended Movies' },
    { type: 'series', id: 'simklpicks.recommended-anime',  name: 'SimklPicks • Recommended Anime' }
  ]
};

const builder = addonBuilder(manifest);

const client = new SimklClient({
  apiKey: process.env.SIMKL_API_KEY,
  accessToken: process.env.SIMKL_ACCESS_TOKEN,
  cacheMinutes: parseInt(process.env.CACHE_MINUTES || '30', 10)
});

builder.defineCatalogHandler(async ({ type, id }) => {
  try {
    const metas = await buildCatalog({ client, type, listId: id });
    return { metas };
  } catch (e) {
    console.error('Catalog error', e);
    return { metas: [] };
  }
});

// Minimal HTTP server (works with all SDK versions)
const addonInterface = builder.getInterface();
const port = Number(process.env.PORT) || 7769;

http
  .createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    addonInterface(req, res);
  })
  .listen(port, () => {
    console.log(`[SimklPicks] listening on :${port}`);
    console.log(`[SimklPicks] manifest: http://localhost:${port}/manifest.json`);
  });
