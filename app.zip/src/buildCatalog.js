import { buildUserProfile, scoreItem, normalizeTopN } from './scorer.js';

function toMetaPreview(simklItem, prefer) {
  const base = simklItem[prefer] || simklItem.show || simklItem.movie || simklItem.anime || simklItem;
  const ids = base?.ids || {};
  const id = ids.imdb || (ids.tmdb ? `tmdb:${ids.tmdb}` : (ids.tvdb ? `tvdb:${ids.tvdb}` : (base?.slug || base?.title)));
  return {
    id,
    name: base?.title || base?.name || base?.show_title || base?.movie_title || 'Unknown',
    poster: base?.poster || base?.image || undefined,
    posterShape: 'poster',
    year: base?.year,
    genres: base?.genres || [],
    ratings: base?.ratings || {}
  };
}
function uniqueById(arr) {
  const seen = new Set(); const out = [];
  for (const it of arr) { if (!it || !it.id) continue; if (seen.has(it.id)) continue; seen.add(it.id); out.push(it); }
  return out;
}
export async function buildCatalog({ client, type, listId }) {
  let historyRaw = [], watchlistRaw = [], ratingsRaw = [], preferKey = type;
  const isAnime = listId === 'simklpicks.recommended-anime';
  if (isAnime) {
    historyRaw = await client.historyAnime();
    watchlistRaw = await client.watchlistAnime();
    ratingsRaw = await client.ratingsAnime();
    preferKey = 'anime';
  } else if (type === 'movie') {
    historyRaw = await client.historyMovies();
    watchlistRaw = await client.watchlistMovies();
    ratingsRaw = await client.ratingsMovies();
    preferKey = 'movie';
  } else {
    historyRaw = await client.historyShows();
    watchlistRaw = await client.watchlistShows();
    ratingsRaw = await client.ratingsShows();
    preferKey = 'show';
  }
  const historyItems = (historyRaw || []).map(x => toMetaPreview(x, preferKey));
  const watchlistItems = (watchlistRaw || []).map(x => toMetaPreview(x, preferKey));
  const watchIds = new Set(watchlistItems.map(i => i.id));
  let pool = uniqueById([...watchlistItems, ...historyItems]);
  if (!isAnime && preferKey === 'movie') {
    const watched = new Set(historyItems.map(i => i.id));
    pool = pool.filter(i => !watched.has(i.id));
  }
  const profile = buildUserProfile({ history: historyRaw });
  const scored = pool.map(item => ({
    ...item,
    score: scoreItem({ item, inWatchlist: watchIds.has(item.id), profile })
  }));
  return normalizeTopN(scored, 50);
}
