console.log('Provide SIMKL_ACCESS_TOKEN in .env');
