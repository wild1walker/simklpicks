import 'dotenv/config';
import http from 'http';
import { SimklClient } from './simklClient.js';
import { buildCatalog } from './buildCatalog.js';

const manifest = {
  id: 'org.abraham.simklpicks',
  version: '1.2.2',
  name: 'SimklPicks',
  description: 'Recommendations from your Simkl watchlists & history',
  resources: ['catalog'],
  types: (process.env.TYPES || 'movie,series').split(',').map(s => s.trim()),
  idPrefixes: ['tt', 'tmdb', 'tvdb'],
  catalogs: [
    { type: 'series', id: 'simklpicks.recommended-series', name: 'SimklPicks • Recommended Series' },
    { type: 'movie',  id: 'simklpicks.recommended-movies', name: 'SimklPicks • Recommended Movies' },
    { type: 'series', id: 'simklpicks.recommended-anime',  name: 'SimklPicks • Recommended Anime' }
  ]
};

const client = new SimklClient({
  apiKey: process.env.SIMKL_API_KEY,
  accessToken: process.env.SIMKL_ACCESS_TOKEN,
  cacheMinutes: parseInt(process.env.CACHE_MINUTES || '30', 10)
});

function sendJson(res, obj, code = 200) {
  const data = JSON.stringify(obj);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-store'
  });
  res.end(data);
}

function notFound(res) {
  res.writeHead(404, { 'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*' });
  res.end('Not found');
}

const port = Number(process.env.PORT) || 7769;

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const parts = url.pathname.split('/').filter(Boolean);

    if (url.pathname === '/' || url.pathname === '/health' || url.pathname === '/_health') {
      res.writeHead(200, { 'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*' });
      res.end('ok');
      return;
    }

    if (url.pathname === '/manifest.json') {
      return sendJson(res, manifest);
    }

    if (parts[0] === 'catalog') {
      const type = parts[1];                    // movie | series
      const idWithExt = parts[2] || '';         // "simklpicks.recommended-..." + ".json"
      if (!type || !idWithExt) return notFound(res);
      const id = idWithExt.replace(/\.json$/i, '');

      try {
        const metas = await buildCatalog({ client, type, listId: id });
        return sendJson(res, { metas });
      } catch (e) {
        console.error('Catalog handler error:', e);
        return sendJson(res, { metas: [] });
      }
    }

    return notFound(res);
  } catch (err) {
    console.error('Server error:', err);
    sendJson(res, { error: 'internal' }, 500);
  }
}).listen(port, () => {
  console.log(`[SimklPicks] listening on :${port}`);
  console.log(`[SimklPicks] manifest: http://localhost:${port}/manifest.json`);
});
