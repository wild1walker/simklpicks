# SimklPicks v3 — Stremio addon
Three catalogs from your Simkl history/watchlists:
- SimklPicks • Recommended Series
- SimklPicks • Recommended Movies
- SimklPicks • Recommended Anime (under Series)

## Run locally
1) cp .env.example .env  (fill SIMKL_API_KEY + SIMKL_ACCESS_TOKEN)
2) npm i
3) npm start
4) Install http://localhost:7769/manifest.json in Stremio

## Deploy (Dockerfile included)
- Add env vars: SIMKL_API_KEY, SIMKL_ACCESS_TOKEN, PORT=7769, CACHE_MINUTES=30
