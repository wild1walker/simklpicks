# SimklPicks — no-SDK web layer
We serve the Stremio Addon endpoints directly (no stremio-addon-sdk HTTP layer).

Endpoints:
- `/manifest.json`
- `/catalog/{type}/{id}.json` (and the `{extra}.json` variant)
- `/`, `/health` → `ok` (for hosts like Koyeb)

## Run locally
1) `cp .env.example .env` and fill SIMKL_API_KEY + SIMKL_ACCESS_TOKEN
2) `npm i`
3) `npm start`
4) Install `http://localhost:7769/manifest.json` in Stremio
